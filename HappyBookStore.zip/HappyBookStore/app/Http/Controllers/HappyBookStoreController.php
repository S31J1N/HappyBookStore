<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;

class HappyBookStoreController extends Controller
{
    public function index(){
        $categories = Category::all();
        $books = Book::with('detail')->get();
        return view('home', compact('categories', 'books'));
    }
    
    public function show($id){
        $categories = Category::all();
        $book = Book::with('detail')->find($id);
        return view('detail', compact('book', 'categories'));
    }
    
    public function category($id){
        $categories = Category::all();
        $bookCategory = Category::find($id);
        $books = Book::where('category_id', $id)->with('detail')->get();
        return view('category', compact('bookCategory', 'books', 'categories'));
    }
    
    public function contact(){
        $categories = Category::all();
        return view('contact', compact('categories'));
    }
}
