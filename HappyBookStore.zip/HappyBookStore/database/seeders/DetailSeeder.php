<?php

namespace Database\Seeders;

use Faker\Provider\Lorem;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for ($i = 0; $i < 6; $i++) {
            DB::table('details')->insert([
                [
                    'book_id' => 1,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 1',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 2,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 2',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 3,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 3',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 4,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 4',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 5,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 5',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 6,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 6',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 7,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 7',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 8,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 8',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
                [
                    'book_id' => 9,
                    'author' => 'Someone Who Cares',
                    'publisher' => 'Publisher 9',
                    'year' => rand(2000, 2018),
                    'description' => Lorem::paragraph(rand(1, 3)),
                ],
            ]);
        }
    }
}
