@extends('layout') 
@section('title', 'Home') 
@section('content')
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link text-primary" href="{{ route('home') }}">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link text-primary dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Category
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        @foreach ($categories as $category)
                        <li>
                            <a class="dropdown-item" href="{{ route('category', $category->id) }}">{{ $category->category }}</a>
                        </li>
                        @endforeach
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-primary" href="{{ route('contact') }}">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-10">
            <div class="bg-warning p-2">Contact</div>
                <h1>Store Address : </h1>
                <p>
                    Jalan Pembangunan Baru Raya, <br>
                    Kompleks Pertokoan Emerald Blok III/12 <br>
                    Bintaro, Tangerang Selatan <br>
                    Indonesia
                </p>
                <h1>Open Daily : </h1>
                <p>
                    08.00 - 20.00
                </p>
                <h1>Contact : </h1>
                <p>
                    Phone : 021-08899776655
                    Email : happybookstore@happy.com
                </p>
        </div>
        <div class="col-md-2">
            <div class="bg-warning p-2">Category</div>
            <div>
                <ul class="list-group">
                    @foreach($categories as $category)
                    <li class="list-group-item">
                        <a href="{{ route('category', $category->id) }}">{{ $category->category }}</a>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection